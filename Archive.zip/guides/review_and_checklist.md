# Review & Checklist — How‑To + Rubric (Single Source of Truth)

Use this for every change. Goal: **simplest robust** solution that is restart‑safe, idempotent, and observable.

## Blocking Gate — Secret & Identifying Material
- Compliant with `spec/security.md` (no secret or identifying material present).

If detected:
- Mark as ❌
- Stop review
- Do not continue architectural analysis

## A) Review Flow (Detailed)
0) **System Impact Classification**: Before review, classify the system by **worst-credible impact if it fails** (Class A–D) using `/guides/system_impact_class.md`.
   - Record the selected class.
   - Briefly note the worst-credible failure mode.
   - Document any **Context Elevation** reasoning if applicable.
   - The assigned class determines the required rigor for all subsequent review steps.
1) **KISS gate**  
   - Propose a simpler alternative if one exists; document why rejected.  
   - For complex problems, present **3–10 options** and choose the simplest viable.
2) **Syntax & Structure**  
   - Use **current release -1** as minimum YAML/Jinja standards (per Home Assistant docs); reject deprecated or "also works" syntax.
   - GUI‑friendly YAML: `alias`, `description`; plural keys; `id:` per trigger; `alias:` at all levels (triggers/conditions/actions/variables/repeat branches).
   - **Comments only in template sensors** (`#debug_*`, `# deps:`, `# verified:`). Automations and scripts use `alias:` and `description:` only.
3) **DTT Probes (Developer Tools → Template) — Mandatory Pre-Deployment**  
   - Test all Jinja, entity references, and sensor outputs **before** writing YAML. Verify entities exist with correct names (account for system naming quirks), and confirm sensors produce expected outputs.
   - Test with actual entity states from your HA instance. For unavailable entities (e.g., solar production at night) or extreme values, confirm the entity exists and structure, then override with test values to validate logic branches.
   - If logic passes DTT but fails after deployment, iteratively refine in DTT until it works live.
   - Use cookbook snippets for availability/defaults, entity name checks, time math.
4) **Traces vs DTT**  
   - Use **DTT** for template logic and unit‑style checks.  
   - Use **Automation Traces** only when orchestration/timing must be verified. No repo‑wide `store_traces: true` mandate.
5) **Live Test**  
   - Exercise a happy‑path trigger. Observe Logbook only for significant events; otherwise remain silent.
6) **Best-in-Class Review (Intent Alignment)**  
   - For all code, ask:
     1. **Primary intent?** (Lights ON = speed; Lights OFF = validation; Recovery = network efficiency; Notification = reliability)
     2. **Implementation matches intent?** (Minimize checks for ON; rich validation for OFF; sequential+guarded for recovery)
     3. **Conditions in right place?** (Cheap checks first in conditions block; expensive operations only on needed paths)
     4. **Network traffic minimized?** (Z-Wave/Zigbee sequential+delayed; HA helpers redundant-call-safe; light transitions batched)
7) **Wait Conditions & Timeouts**  
   - Prefer `wait_template` with timeout over fixed delays when feasible.
   - Include `continue_on_timeout: true` for graceful fallthrough.
   - Guard exclusion lists: always check for empty string `''` in negation filters (e.g., `not in ['dead','unknown','unavailable','']`).
8) **Restart & Recovery**  
   - Critical paths: **fixed `<10s` `for:`** on `timer.ha_startup_delay` trigger.  
   - Non‑critical: **randomized `for:` (e.g., 45–75s)** on the trigger.  
   - No artificial `delay` actions for staggering; use the trigger's `for:` instead.
9) **Idempotency & Chatter**  
   - Guard device calls; batch by group/area; rate‑limit noisy inputs; minimal bounded retry.
10) **Overrides & Safety**  
   - Manual/guest/safety modes always win. See `/spec/safety.md` for patterns.
11) **Backward-Incompatible Changes (12 months)**  
   - Any refactor or enhancement MUST review the last 12 months of Home Assistant release notes and proactively adapt for **backward-incompatible (breaking) changes** affecting schemas, services, attributes, or behavior.  
   - The reviewer must confirm in their response: **"BC review: done"** or **"BC review: N/A"**.
12) **Changelog & Versioning**
   - Format: `YYYYMMDD-HHMM: Single sentence summary.`  
   - Timezone: **America/Los_Angeles** (local time).
  a) **Automations & Scripts**  
    - Add **CHANGELOG** block in YAML `description:` (not YAML `#` comments).  
    - `description:` is Markdown-rendered; when using list items (`- ...`), a blank line MUST separate `CHANGELOG:` from the first item.
  b) **YAML-defined entities (e.g., template sensors)**  
    - Use YAML `# CHANGELOG:` comments near the top of the definition.
13) **Exceptions**  
   - Deviations allowed **only if documented inline** (in `description`, `alias`, or sensor comments).
14) **Self‑Critique & Verdict**  
   - Risks, alternatives, rollback. Verdict categories below.
15) **Blueprint Validation (if used)**
   - Confirm compliance with the official Home Assistant blueprint schema and validate at least one instantiated artifact against all standard automation/script expectations before approval.
16) **Household UX / Annoyance Risk Review (HAF) completed**
   - Confirm the change does not introduce new human-impact failure modes. High-impact risks must be mitigated, documented as accepted tradeoffs, or the change must not ship.


## B) Verdicts
- **Production‑ready** · **Low‑risk w/ notes** · **Needs revision** · **Do not ship**

## C) Copy‑Paste Checklists
### Master
- [ ] KISS & scope clear; simpler alternative considered/ruled out
- [ ] GUI‑friendly automation/script YAML; `alias:` mandatory at all levels; `description:` at automation/script/sensor level; `id:` per trigger
- [ ] `max_exceeded: silent` considered for automations that fire frequently or have significant risk of exceeding `max`
- [ ] **Comments policy**: Automations/scripts are **comment-free YAML**; intent lives only in `alias:` and `description:`. Template sensors **must** include inline comments and commented `#debug_*` attributes. AppDaemon comments for complex logic only
- [ ] **Startup triggers** only when post-restart actions needed (state recovery, initialization); avoid for passive automations
- [ ] Brains vs muscles respected; scripts for fan‑outs; concurrency sane
- [ ] Control flow safety: `if/then` wraps `choose/default` branches (prevents unwanted default execution)
- [ ] Restart gates on triggers (`timer.ha_startup_delay` w/ appropriate `for:`); **no action delays**
- [ ] State trigger `to:`/`from:` and event trigger `event_type:` are **literal string matches only** — never Jinja; `for:` does accept Jinja; use `platform: template` + `value_template:` for evaluated expressions
- [ ] Jinja safety: safe defaults (`| float(0)`, `| int(0)`)
- [ ] No Python methods (`.get()`, `.items()`, `.total_seconds()`, etc.)
- [ ] No direct state-object access (e.g., `states.sensor.x.last_changed`) except `.last_updated` / `.last_changed` for staleness or age calculations; must be guarded and used only for time semantics
- [ ] String normalization: `| lower | trim`
- [ ] Time math: `as_timestamp()` not `.total_seconds()`
- [ ] Deferred-intent datetime helpers follow canonical pattern (full datetime, sentinel `2999-01-01 00:00:00`, no null/blank, literal sentinel comparison)
  - Does NOT apply to non-deferred timestamps (e.g., chatter-control like "last applied", "last run")
- [ ] Type safety: raw/typed variables separated; comparisons use typed with tolerance
- [ ] Availability: `has_value()` for entity checks (1)
- [ ] Event-driven preferred; if polling, ≥60s & justified
- [ ] Fast-fail condition ordering: cheap checks first; likely failures early; expensive Jinja last
- [ ] Chatter minimized; idempotent guards; groups/areas; rate‑limit as needed
- [ ] Observability: `reason` attr when external or ambiguous inputs exist; production logs only for significant events
- [ ] DTT probes provided; traces referenced if orchestration validated
- [ ] Best-in-class review completed: intent clarity, implementation alignment, condition placement, network efficiency
- [ ] Wait strategies: `wait_template` preferred; exclusion lists guard empty string; `continue_on_timeout: true` used
- [ ] Backward-incompatible changes (12 months) reviewed
- [ ] Exceptions documented inline (description/alias/comments)
- [ ] Risks/alternatives/rollback documented; verdict chosen
- [ ] Household UX / Annoyance Risk Review (HAF) completed (see sub-checklist)

### Automation Sub‑Checklist
- [ ] Minimal, precise triggers; unique `id` and `alias`
- [ ] Randomized vs fixed `for:` per criticality on HA restart
- [ ] Variables computed once at the narrowest appropriate scope; branches small & ordered cheap→expensive
- [ ] Deferred-intent datetime helpers (deadline-style `input_datetime`) declare owner and overdue policy in `description:` and implement explicit consume behavior (clear or re-arm)
- [ ] No device calls inside loops without guards
- [ ] No recursive loop: if trigger entity == action target entity, a `to:` constraint and re-entry condition are mandatory
- [ ] No logging; description/alias carry intent only
- [ ] Trigger coverage: each trigger ID referenced exactly once; else: branch logs trigger.id for catch-all validation
- [ ] Empty `metadata: {}`/`data: {}` blocks: acceptable if GUI-edited (editor auto-adds); remove only in pure-YAML workflows
- [ ] Automation/script CHANGELOG formatting correct:
  - two blank lines before **CHANGELOG:**
  - `**CHANGELOG:**` (bold + caps)
  - one blank line after header
  - one blank line between each entry

### Script Sub‑Checklist
- [ ] `mode` and `max` reflect expected concurrency
- [ ] Centralizes device calls; idempotent guard; optional bounded retry
- [ ] No logging except significant failure paths
- [ ] No comments; description/alias carry context

### Template Sensor Sub‑Checklist
- [ ] Minimal trigger set + HA startup gate
- [ ] Clear directive state + `reason` attribute
- [ ] Safe reads; expected commented `#debug_…` attributes
- [ ] Optional `# deps:` and `# verified:` documentation for clarity
- [ ] Accumulating dict-merge sensors: byte-length pre-check before commit (`proposed | tojson | length > 16384`)

### Time Math & Timezone Safety Sub-Checklist
- [ ] Conversions explicit and consistent (`as_timestamp()` for math; `as_datetime()` only for parsing/display)
- [ ] Local vs UTC intentional (`now()` vs `utcnow()`); no mixing within a calculation
- [ ] Staleness/age math safe for `none`/invalid datetimes (guard + safe default like `999999`)
- [ ] Time-of-day logic uses numeric comparisons (hour/minutes), not `"HH:MM"` string comparisons
- [ ] Randomized delays/schedules correct and deterministic for intent (inclusive ranges; `range(45, 76)` for "45–75")
- [ ] Once-per-day schedules account for DST (anchored `at:` vs elapsed-time logic)
- [ ] Datetime comparisons avoid Python methods; use timestamp filters for day-level logic (e.g., no `.date()`)
- [ ] Datetime parsing uses safe fallback (`as_datetime(value, default)`)

### Datetime vs Timer Selection
- [ ] `input_datetime` used for persisted deferred intent (restart-safe deadlines, gating)
- [ ] `timer` used only for:
  - countdown UX
  - cancelable grace windows
  - protective cooldowns (e.g., compressor or API lockout)
- [ ] Timer usage includes explicit justification if not obvious

### Deterministic Execution
- [ ] No templated randomization in critical paths (or documented as accepted tradeoff)
- [ ] Post-restart gates use 45–75s random `for:` delay (prevents thundering herd)

### Household UX / Annoyance Risk Sub-Checklist *(aka Household Approval Factor – HAF)*
**This review is performed AFTER all technical, structural, and safety checks are complete.**

- [ ] False-trigger probability evaluated
- [ ] Oscillation / repeated toggle risk evaluated
- [ ] Notification fatigue risk evaluated
- [ ] Sleep disruption risk evaluated (late night / early morning behavior)
- [ ] Manual override conflict evaluated ("automation fighting humans")
- [ ] Restart recovery annoyance evaluated
- [ ] Sensor chatter / flapping risk evaluated
- [ ] Guest-mode behavior considered
- [ ] Silent failure modes identified
- [ ] Trust erosion vectors identified (conditions that would cause someone to disable the automation)
- [ ] High-impact annoyance risks mitigated, documented, or explicitly accepted as tradeoffs

-----
(1) If the source is known to emit blank strings, add and (states(...)|trim) != ''.
